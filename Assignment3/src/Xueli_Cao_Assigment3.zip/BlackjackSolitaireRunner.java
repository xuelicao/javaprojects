/**
 * game runner class
 * @author Xueli Cao
 *
 */
public class BlackjackSolitaireRunner {
	public static void main(String[] args) {
		BlackjackSolitaire bjs = new BlackjackSolitaire();
		bjs.play();
	}
}



